# Lancement

```bash
npm install
npm run dev
```